#pragma once
namespace ObjectInit
{
    /// <summary>
    /// ����������I�u�W�F�N�g�̎��
    /// </summary>
    enum class InitObjKind
    {
        player,
        moveSaw,
        saw,
        bomberShip,
        bomber,
        upDownLaserShip,
        circleLaserShip,
        laser,
        collect,
        stageFloor,
        skyDome,
        wall
    };
}